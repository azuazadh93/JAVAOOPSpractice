package com.cts.interface1;
public class PGStudent implements Student {
    String name;
    String id;
    int age;
    double grade;
    String address;
    private String specialization;
    private int noOfPapersPublished;

    public PGStudent(String name, String id, int age, double grade, String address, String specialization, int noOfPapersPublished)
    {
        this.name = name;
        this.id = id;
        this.age = age;
        this.grade = grade;
        this.address = address;
        this.specialization = specialization;
        this.noOfPapersPublished = noOfPapersPublished;
    }
    public void display()
    {
        System.out.println("Name : "+name);
        System.out.println("Id : "+id);
        System.out.println("Age : "+age);
        System.out.println("Grade : "+grade);
        System.out.println("Address : "+address);
        System.out.println("Specialization : "+specialization);
        System.out.println("No. of papers published : "+noOfPapersPublished);

    }
    public boolean isPassed()
    {
        if(this.grade>70 && noOfPapersPublished>=2)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

}
