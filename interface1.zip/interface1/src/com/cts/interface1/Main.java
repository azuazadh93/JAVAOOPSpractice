package com.cts.interface1;

import java.util.Scanner;
public class Main{
    public static void main(String args[]) {
        Scanner in = new Scanner(System.in);
        System.out.println("Menu");
        System.out.println("1) Create a UG Student");
        System.out.println("2) Create a PG Student");
        System.out.println("Enter your choice");
        int choice = in.nextInt();
        System.out.println("Enter name");
        String name = in.nextLine();
        in.nextLine();
        System.out.println("Enter id");
        String id = in.nextLine();
        System.out.println("Enter age");
        int age = in.nextInt();
        System.out.println("Enter grade");
        double grade = in.nextDouble();
        System.out.println("Enter address");
        String address = in.nextLine();
        in.nextLine();
        switch (choice) {
            //PGStudent
            case 1:
                System.out.println("Enter degree");
                String degree = in.nextLine();
                System.out.println("Enter stream");
                String stream = in.nextLine();
                Student ugstudent = new UGStudent(name, id, age, grade, address, degree, stream);
                System.out.println("UG Student Details");
                ugstudent.display();
                if(ugstudent.isPassed())
                    System.out.println("Result : Pass");
                else
                    System.out.println("Result : Fail");

                break;
//UG
            case 2:
                System.out.println("Enter specialization");
                String specialization = in.nextLine();
                System.out.println("Enter number of papers published");
                int noOfPapers = in.nextInt();
                PGStudent pgstudent = new PGStudent(name, id, age, grade, address, specialization, noOfPapers);
                System.out.println("PG Student Details");
                pgstudent.display();
                if(pgstudent.isPassed())
                    System.out.println("Result : Pass");
                else
                    System.out.println("Result : Fail");
                break;
            default:
                break;


        }
    }

}
