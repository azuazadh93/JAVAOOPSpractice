abstract class Shape {
    protected String shapeName;

    Shape(String shapeName)
    {
        this.shapeName=shapeName;
    }
    abstract double calculateArea();

}
